/**
 * @file kick.h
 * @brief  kick trajectory
 *
 * @author wq
 * @date September 23, 2024
 * @version v1.0.2
 * @bug No known bugs
 *
 * @copyright Copyright (c) 2024, shanghai fourier intelligence

 */

#pragma once

#include "humanoid/foot_trajectory.h"
#include "humanoid/humanoid_robot.h"
#include "tools/cubic_spline_3d.h"

namespace grx_sot::humanoid {
class Kick {
 public:
    struct KickTrajectory : FootTrajectory {
        Eigen::Vector3d pos(double t);
        Eigen::Vector3d vel(double t);

        grx_sot::tools::CubicSpline3D foot_trajectory;
    };

    static KickTrajectory make_trajectory(HumanoidRobot::Side kicking_side,
                                          double t_start, double t_end,
                                          Eigen::Vector3d start,
                                          Eigen::Vector3d target,
                                          Eigen::Affine3d T_world_opposite,
                                          HumanoidParameters &parameters);

    // double kicking_com_height = 0.32;
    // double feet_spacing = 0.12;
    // double com_support_offset = 0.02;
};
}  // namespace grx_sot::humanoid
