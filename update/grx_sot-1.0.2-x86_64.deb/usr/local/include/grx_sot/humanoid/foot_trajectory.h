/**
 * @file foot_trajectory.h
 * @brief  foot trajectory.
 *
 * @author wq
 * @date September 23, 2024
 * @version v1.0.2
 * @bug No known bugs
 *
 * @copyright Copyright (c) 2024, shanghai fourier intelligence

 */

#pragma once

#include "humanoid/humanoid_parameters.h"
#include <Eigen/Dense>

namespace grx_sot::humanoid {
struct FootTrajectory {
 public:
    virtual ~FootTrajectory();
    virtual Eigen::Vector3d pos(double t) = 0;
    virtual Eigen::Vector3d vel(double t) = 0;

    double t_start, t_end;
};
}  // namespace grx_sot::humanoid
