/**
 * @file swing_foot_quintic.h
 * @brief  quintic swing
 *
 * @author wq
 * @date September 23, 2024
 * @version v1.0.2
 * @bug No known bugs
 *
 * @copyright Copyright (c) 2024, shanghai fourier intelligence

 */

#pragma once

#include "humanoid/humanoid_parameters.h"
#include <Eigen/Dense>

namespace grx_sot::humanoid {
/**
 * @brief A quintic fitting of the swing foot
 */
class SwingFootQuintic {
 public:
    struct Trajectory {
        Eigen::Vector3d pos(double t);
        Eigen::Vector3d vel(double t);

        // Computed polynom (ax^5 + bx^4 + cx^3 + dx^2 + ex + f)
        Eigen::Vector3d a, b, c, d, e, f;

        double t_start, t_end;
    };

    static Trajectory make_trajectory(double t_start, double t_end,
                                      double height, Eigen::Vector3d start,
                                      Eigen::Vector3d target);
};
}  // namespace grx_sot::humanoid
