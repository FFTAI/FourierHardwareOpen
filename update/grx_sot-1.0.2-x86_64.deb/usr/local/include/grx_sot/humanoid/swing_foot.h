/**
 * @file swing_foot.h
 * @brief  base class
 *
 * @author wq
 * @date September 23, 2024
 * @version v1.0.2
 * @bug No known bugs
 *
 * @copyright Copyright (c) 2024, shanghai fourier intelligence

 */

#pragma once

#include "humanoid/foot_trajectory.h"
#include "humanoid/humanoid_parameters.h"
#include <Eigen/Dense>

namespace grx_sot::humanoid {
/**
 * @brief A cubic fitting of swing foot, see:
 * https://scaron.info/doc/pymanoid/walking-pattern-generation.html#pymanoid.swing_foot.SwingFoot
 */
class SwingFoot {
 public:
    struct Trajectory : FootTrajectory {
        Eigen::Vector3d pos(double t);
        Eigen::Vector3d vel(double t);

        // Computed polynom (ax^3 + bx^2 + cx + d)
        Eigen::Vector3d a, b, c, d;
    };

    static Trajectory make_trajectory(double t_start, double t_end,
                                      double height, Eigen::Vector3d start,
                                      Eigen::Vector3d target);

    static Trajectory remake_trajectory(Trajectory &old_trajectory, double t,
                                        Eigen::Vector3d target);
};
}  // namespace grx_sot::humanoid
