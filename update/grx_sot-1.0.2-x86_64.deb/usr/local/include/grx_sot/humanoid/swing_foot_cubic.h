/**
 * @file swing_foot_cubic.h
 * @brief  cubic swing
 *
 * @author wq
 * @date September 23, 2024
 * @version v1.0.2
 * @bug No known bugs
 *
 * @copyright Copyright (c) 2024, shanghai fourier intelligence

 */

#pragma once

#include "humanoid/foot_trajectory.h"
#include "humanoid/humanoid_parameters.h"
#include "tools/cubic_spline.h"
#include <Eigen/Dense>

namespace grx_sot::humanoid {
    /**
     * @brief Cubic swing foot
     */
    class SwingFootCubic {
     public:
        struct Trajectory : FootTrajectory {
            virtual Eigen::Vector3d pos(double t);
            virtual Eigen::Vector3d vel(double t);

            grx_sot::tools::CubicSpline x;
            grx_sot::tools::CubicSpline y;
            grx_sot::tools::CubicSpline z;

            double t_start;
            double virt_duration;
        };

        static Trajectory make_trajectory(double t_start, double virt_duration, double height,
                                          double rise_ratio, Eigen::Vector3d start,
                                          Eigen::Vector3d target, double elapsed_ratio = 0.,
                                          Eigen::Vector3d start_vel = Eigen::Vector3d::Zero());
    };
}  // namespace grx_sot::humanoid
