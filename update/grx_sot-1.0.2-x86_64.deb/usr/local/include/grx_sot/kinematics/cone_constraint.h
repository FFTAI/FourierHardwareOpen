/**
 * @file cone_constraint.h
 * @brief z-axis of frame a and frame b should remain within a cone of a angle .
 *
 * @author wq
 * @date September 22, 2024
 * @version v1.0.2
 * @bug No known bugs
 *
 * @copyright Copyright (c) 2024, shanghai fourier intelligence

 */

#pragma once

#include <vector>
#include "problem/problem.h"
#include "kinematics/constraint.h"
#include "robot/robot_wrapper.h"

namespace grx_sot::kinematics {
class KinematicsSolver;

/**
 * @brief A cone constraint is a constraint where the z-axis of frame a and frame b should remain within a cone of
 * angle angle_max.
 */
class ConeConstraint : public Constraint {
 public:
  /**
   * @brief With a cone constraint, the z-axis of frame a and frame b should remain within a cone of angle angle_max
   * @param frame_a
   * @param frame_b
   * @param angle_max
   */
  ConeConstraint(robot::RobotWrapper::FrameIndex frame_a,
    robot::RobotWrapper::FrameIndex frame_b, double angle_max);

  /**
   * @brief Frame A
   */
  robot::RobotWrapper::FrameIndex frame_a;

  /**
   * @brief Frame B
   */
  robot::RobotWrapper::FrameIndex frame_b;

  /**
   * @brief Maximum angle allowable by the cone constraint (between z-axis of frame_a and frame_b)
   */
  double angle_max;

  /**
   * @brief Number of slices used to discretize the cone
   */
  int N = 8;

  /**
   * @brief Range of the cone discretization (in radians). The cone is discretized in [-range, range] around
   * the current orientation.
   */
  double range = 0.25;

  void add_constraint(grx_sot::problem::Problem& problem) override;
};
}  // namespace grx_sot::kinematics
