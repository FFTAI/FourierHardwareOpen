/**
 * @file constraint.h
 * @brief base constraint class .
 * @author wq
 * @date September 22, 2024
 * @version v1.0.2
 * @bug No known bugs
 *
 * @copyright Copyright (c) 2024, shanghai fourier intelligence

 */

#pragma once

#include "problem/problem.h"
#include "tools/prioritized.h"

namespace grx_sot::kinematics {
class KinematicsSolver;
class Constraint : public tools::Prioritized {
 public:
  /**
   * @brief Reference to the kinematics solver
   */
  KinematicsSolver* solver = nullptr;

  /**
   * @brief true if this object memory is in the solver (it will be deleted by the solver)
   */
  bool solver_memory = false;

  virtual void add_constraint(
      grx_sot::problem::Problem& problem) = 0;
};
}  // namespace grx_sot::kinematics
