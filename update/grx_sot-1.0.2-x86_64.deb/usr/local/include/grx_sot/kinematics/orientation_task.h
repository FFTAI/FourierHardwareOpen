/**
 * @file orientation.h
 * @brief orientation task.
 * @author wq
 * @date September 22, 2024
 * @version v1.0.2
 * @bug No known bugs
 *
 * @copyright Copyright (c) 2024, shanghai fourier intelligence

 */

#pragma once

#include <string>
#include "kinematics/task.h"
#include "tools/axises_mask.h"

namespace grx_sot::kinematics {
class KinematicsSolver;
struct OrientationTask : public Task
{
  /**
   * @brief See \ref KinematicsSolver::add_orientation_task
   */
  OrientationTask(robot::RobotWrapper::FrameIndex frame_index,
    Eigen::Matrix3d R_world_frame);

  /**
   * @brief Frame
   */
  robot::RobotWrapper::FrameIndex frame_index;

  /**
   * @brief Target frame orientation in the world
   */
  Eigen::Matrix3d R_world_frame;

  virtual void update();
  virtual std::string type_name();
  virtual std::string error_unit();

  /**
   * @brief Mask
   */
  tools::AxisesMask mask;
};
}  // namespace grx_sot::kinematics
