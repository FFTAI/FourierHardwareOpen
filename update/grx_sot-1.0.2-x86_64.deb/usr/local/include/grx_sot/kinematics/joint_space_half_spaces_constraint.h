/**
 * @file joint_space_half_spaces_constraint.h
 * @brief joint space task .
 * @author wq
 * @date Mar 28, 2025
 * @version v1.0.2
 * @bug No known bugs
 *
 * @copyright Copyright (c) 2025, shanghai fourier intelligence

 */

#pragma once

#include <vector>
#include "problem/problem.h"
#include "kinematics/constraint.h"

namespace grx_sot::kinematics {
class KinematicsSolver;
class JointSpaceHalfSpacesConstraint : public Constraint {
 public:
    /**
     * @brief Ensures that, in joint-space we have Aq <= b
     *        Note that the floating base terms will be ignored in A. However, A should still be of
     *        dimension n_constraints x n_q
     */
    JointSpaceHalfSpacesConstraint(const Eigen::MatrixXd A, Eigen::VectorXd b);

    /**
     * @brief Matrix A in Aq <= b
     */
    Eigen::MatrixXd A;

    /**
     * @brief Vector b in Aq <= b
     */
    Eigen::VectorXd b;

    virtual void add_constraint(grx_sot::problem::Problem& problem) override;
};
}  // namespace grx_sot::kinematics
