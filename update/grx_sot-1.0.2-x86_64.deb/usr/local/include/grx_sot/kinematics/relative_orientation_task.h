/**
 * @file relative_orientation_task.h
 * @brief relative orientation task.
 * @author wq
 * @date September 22, 2024
 * @version v1.0.2
 * @bug No known bugs
 *
 * @copyright Copyright (c) 2024, shanghai fourier intelligence

 */

#pragma once

#include <string>
#include "kinematics/task.h"
#include "tools/axises_mask.h"

namespace grx_sot::kinematics {
class KinematicsSolver;

struct RelativeOrientationTask : public Task {
  /**
   * @brief See \ref KinematicsSolver::add_relative_orientation_task
   */
  RelativeOrientationTask(
    robot::RobotWrapper::FrameIndex frame_a,
    robot::RobotWrapper::FrameIndex frame_b,
     Eigen::Matrix3d R_a_b);

  /**
   * @brief Frame A
   */
  robot::RobotWrapper::FrameIndex frame_a;

  /**
   * @brief Frame B
   */
  robot::RobotWrapper::FrameIndex frame_b;

  /**
   * @brief Target relative orientation of b in a
   */
  Eigen::Matrix3d R_a_b;

  virtual void update();
  virtual std::string type_name();
  virtual std::string error_unit();

  /**
   * @brief Mask
   */
  tools::AxisesMask mask;
};
}  // namespace grx_sot::kinematics
