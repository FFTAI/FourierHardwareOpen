/**
 * @file avoid_self_collisions_constraint.h
 * @brief avoid self collision constraint .
 *
 * @author wq
 * @date September 22, 2024
 * @version v1.0.2
 * @bug No known bugs
 *
 * @copyright Copyright (c) 2024, shanghai fourier intelligence

 */

#pragma once

#include "problem/problem.h"
#include "kinematics/constraint.h"

namespace grx_sot::kinematics {
class KinematicsSolver;
class AvoidSelfCollisionsConstraint : public Constraint {
 public:
  /**
   * @brief Margin for self collisions [m]
   */
  double self_collisions_margin = 0.005;

  /**
   * @brief Distance that triggers the constraint [m]
   */
  double self_collisions_trigger = 0.01;

  void add_constraint(
      grx_sot::problem::Problem& problem) override;
};
}  // namespace grx_sot::kinematics
