/**
 * @file axis_align_task.h
 * @brief look at a point in world .
 *
 * @author wq
 * @date September 22, 2024
 * @version v1.0.2
 * @bug No known bugs
 *
 * @copyright Copyright (c) 2024, shanghai fourier intelligence

 */
#pragma once

#include <string>

#include "kinematics/task.h"

namespace grx_sot::kinematics {
class KinematicsSolver;
struct AxisAlignTask : public Task {
  AxisAlignTask(robot::RobotWrapper::FrameIndex frame_index,
    Eigen::Vector3d axis_frame,
    Eigen::Vector3d targetAxis_world);

  /**
   * @brief Target frame
   */
  robot::RobotWrapper::FrameIndex frame_index;

  /**
   * @brief Axis in the frame
   */
  Eigen::Vector3d axis_frame;

  /**
   * @brief Target axis in the world
   */
  Eigen::Vector3d targetAxis_world;

  virtual void update();
  virtual std::string type_name();
  virtual std::string error_unit();
};
}  // namespace grx_sot::kinematics
