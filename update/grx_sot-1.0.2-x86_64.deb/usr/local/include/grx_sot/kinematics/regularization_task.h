/**
 * @file regularization_task.h
 * @brief regularization task.
 * @author wq
 * @date September 22, 2024
 * @version v1.0.2
 * @bug No known bugs
 *
 * @copyright Copyright (c) 2024, shanghai fourier intelligence

 */

#pragma once

#include <string>
#include "kinematics/task.h"

namespace grx_sot::kinematics {
class KinematicsSolver;
struct RegularizationTask : public Task {
  virtual void update();
  virtual std::string type_name();
  virtual std::string error_unit();
};
}  // namespace grx_sot::kinematics
