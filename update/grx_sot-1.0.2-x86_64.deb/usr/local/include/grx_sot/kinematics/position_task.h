/**
 * @file position.h
 * @brief position task.
 * @author wq
 * @date September 22, 2024
 * @version v1.0.2
 * @bug No known bugs
 *
 * @copyright Copyright (c) 2024, shanghai fourier intelligence

 */

#pragma once

#include <string>
#include "kinematics/task.h"
#include "tools/axises_mask.h"

namespace grx_sot::kinematics {
class KinematicsSolver;
struct PositionTask : public Task {
  /**
   * @brief See \ref KinematicsSolver::add_position_task
   */
  PositionTask(robot::RobotWrapper::FrameIndex frame_index,
    Eigen::Vector3d target_world);

  /**
   * @brief Frame
   */
  robot::RobotWrapper::FrameIndex frame_index;

  /**
   * @brief Target position in the world
   */
  Eigen::Vector3d target_world;

  virtual void update();
  virtual std::string type_name();
  virtual std::string error_unit();

  /**
   * @brief Mask
   */
  tools::AxisesMask mask;
};
}  // namespace grx_sot::kinematics
