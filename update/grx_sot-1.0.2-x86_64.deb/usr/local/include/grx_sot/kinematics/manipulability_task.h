/**
 * @file manipulability_task.h
 * @brief maximize manipulability .
 * @author wq
 * @date September 22, 2024
 * @version v1.0.2
 * @bug No known bugs
 *
 * @copyright Copyright (c) 2024, shanghai fourier intelligence

 */

#pragma once

#include <string>

#include "kinematics/task.h"

namespace grx_sot::kinematics {
class KinematicsSolver;
struct ManipulabilityTask : public Task {
  enum Type {
    POSITION = 0,
    ORIENTATION = 1,
    BOTH = 2
  };

  ManipulabilityTask(robot::RobotWrapper::FrameIndex frame_index,
    Type type, double lambda_ = 1.0);

  virtual void update();
  virtual std::string type_name();
  virtual std::string error_unit();

  Eigen::MatrixXd mask_matrix(Eigen::MatrixXd M);

  /**
   * @brief Index of the frame we want to set manipulability
   */
  robot::RobotWrapper::FrameIndex frame_index;

  /**
   * @brief Importance of the hessian regularization
   */
  double lambda;

  /**
   * @brief Type of frame manipulability to compute
   */
  Type type;

  /**
   * @brief Should the manipulability be minimized (can be useful to find singularities)
   */
  bool minimize = false;

  /**
   * @brief The last computed manipulability value
   */
  double manipulability = 0.;
};
}  // namespace grx_sot::kinematics
