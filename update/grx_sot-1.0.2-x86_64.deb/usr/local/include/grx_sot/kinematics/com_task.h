/**
 * @file com_task.h
 * @brief com task .
 *
 * @author wq
 * @date September 22, 2024
 * @version v1.0.2
 * @bug No known bugs
 *
 * @copyright Copyright (c) 2024, shanghai fourier intelligence

 */

#pragma once
#include <string>
#include "kinematics/task.h"
#include "tools/axises_mask.h"

namespace grx_sot::kinematics {
class KinematicsSolver;
struct CoMTask : public Task {
  /**
   * @brief See \ref KinematicsSolver::add_com_task
   */
  explicit CoMTask(Eigen::Vector3d target_world);

  /**
   * @brief Target for the CoM in the world
   */
  Eigen::Vector3d target_world;

  virtual void update();
  virtual std::string type_name();
  virtual std::string error_unit();

  /**
   * @brief Mask
   */
  tools::AxisesMask mask;
};
}  // namespace grx_sot::kinematics
