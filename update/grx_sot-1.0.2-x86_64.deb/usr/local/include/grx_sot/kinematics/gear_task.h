/**
 * @file gear_task.h
 * @brief gear task .
 * @author wq
 * @date September 22, 2024
 * @version v1.0.2
 * @bug No known bugs
 *
 * @copyright Copyright (c) 2024, shanghai fourier intelligence

 */

#pragma once

#include <vector>
#include <map>
#include <string>
#include "kinematics/task.h"

namespace grx_sot::kinematics {
class KinematicsSolver;
struct GearTask : public Task {
  /**
   * @brief see \ref KinematicsSolver::add_gear_task
   */
  GearTask();

  /**
   * @brief Gear settings
   */
  std::map<int, std::map<int, double>> gears;

  /**
   * @brief Sets a gear constraint
   * @param target target joint
   * @param source source joint
   * @param ratio ratio
   */
  void set_gear(std::string target, std::string source, double ratio);

  /**
   * @brief Adds a gear constraint, you can add multiple source for the same target, they
   * will be summed
   * @param target target joint
   * @param source source joint
   * @param ratio ratio
   */
  void add_gear(std::string target, std::string source, double ratio);

  virtual void update();
  virtual std::string type_name();
  virtual std::string error_unit();
};
}  // namespace grx_sot::kinematics
