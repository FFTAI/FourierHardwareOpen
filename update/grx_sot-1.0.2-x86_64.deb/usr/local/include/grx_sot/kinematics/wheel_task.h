/**
 * @file wheel_task.h
 * @brief wheel task .
 *
 * @author wq
 * @date September 22, 2024
 * @version v1.0.2
 * @bug No known bugs
 *
 * @copyright Copyright (c) 2024, shanghai fourier intelligence

 */

#pragma once

#include <string>

#include "kinematics/task.h"
#include "tools/axises_mask.h"

namespace grx_sot::kinematics {
class KinematicsSolver;
struct WheelTask : public Task {
  /**
   * @brief See \ref KinematicsSolver::add_wheel_task
   */
  WheelTask(std::string joint, double radius, bool omniwheel = false);

  /**
   * @brief Frame
   */
  std::string joint;

  /**
   * @brief Wheel radius
   */
  double radius;

  /**
   * @brief Omniwheel (can slide laterally)
   */
  bool omniwheel;

  /**
   * @brief Target position in the world
   */
  Eigen::Affine3d T_world_surface;

  virtual void update();
  virtual std::string type_name();
  virtual std::string error_unit();
};
}  // namespace grx_sot::kinematics
