/**
 * @file robot_collision.h
 * @brief define Collision and Distance .
 *
 * @author wq
 * @date September 21, 2024
 * @version v1.0.2
 * @bug No known bugs
 *
 * @copyright Copyright (c) 2024, shanghai fourier intelligence

 */

#pragma once

#include <Eigen/Dense>
#include <vector>
#include <string>
namespace grx_sot::robot {
    /**
     * @brief Represents a collision between two bodies
     */
struct Collision {
    /**
     * @brief Index of object A in the collision geometry
     */
    int objA;

    /**
     * @brief Index of object B in the collision geometry
     */
    int objB;

    /**
     * @brief The joint parent of body A
     */
    pinocchio::JointIndex parentA;

    /**
     * @brief The joint parent of body B
     */
    pinocchio::JointIndex parentB;

    /**
     * @brief Name of the body A
     */
    std::string bodyA;

    /**
     * @brief Name of the body B
     */
    std::string bodyB;

    /**
     * @brief Contact points
     */
    std::vector<Eigen::Vector3d> contacts;

    inline bool operator==(const Collision& other) {
        return (objA == other.objA && objB == other.objB);
    }
};

    /**
     * @brief Represents a distance between two bodies
     */
struct Distance {
    /**
     * @brief Index of object A in the collision geometry
     */
    int objA;

    /**
     * @brief Index of object B in the collision geometry
     */
    int objB;

    /**
     * @brief Parent joint of body A
     */
    pinocchio::JointIndex parentA;

    /**
     * @brief Parent joint of body B
     */
    pinocchio::JointIndex parentB;

    /**
     * @brief Point of object A considered
     */
    Eigen::Vector3d pointA;

    /**
     * @brief Point of object B considered
     */
    Eigen::Vector3d pointB;

    /**
     * @brief Current minimum distance between the two objects
     */
    double min_distance;

    inline bool operator==(const Distance& other) {
        return (objA == other.objA && objB == other.objB);
    }
};

}  // namespace grx_sot::robot
