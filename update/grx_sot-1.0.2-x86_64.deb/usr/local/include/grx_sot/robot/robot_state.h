/**
 * @file robot_state.h
 * @brief define robot state that estimated from sensor data .
 *
 * @author wq
 * @date September 21, 2024
 * @version v1.0.2
 * @bug No known bugs
 *
 * @copyright Copyright (c) 2024, shanghai fourier intelligence

 */

#pragma once

#include <Eigen/Dense>
#include <map>
#include <string>
using Vector6d = Eigen::Matrix<double, 6, 1>;
namespace grx_sot::robot {
    /**
     * @brief robot state estimated from sensor data .
     *
     * @details we use a floating base as a first DoF, the size of ``q`` is not the same as the size 
     * of ``qd``,``qdd``,and ``qft`` .Use @ref RobotWrapper::get_joint_offset (for ``q``) and 
     * @ref RobotWrapper::get_joint_v_offset (for ``qd`` ``qdd`` and ``qft``) to get the offset 
     * of a given DoF in the state . Feel free to add new element and change method in RobotWrapper
     * for example reset().
     */
struct RobotState {
    /**
     * @brief joints configuration \f$ q \f$
     */
    Eigen::VectorXd q;
    /**
     * @brief joints velocity \f$ \dot q \f$
     */
    Eigen::VectorXd qd;
    /**
     * @brief joints acceleration \f$ \ddot q \f$
     */
    Eigen::VectorXd qdd;
    /**
     * @brief joints force or torque
     */
    Eigen::VectorXd qft;
    /**
     * @brief external forces of robot, include link name and magnitude of force ，
     * The first three components represent force with units in Newtons (N), and 
     * the last three components represent torque with units in Newton-meters (N·m).
     */
    std::map<std::string, Vector6d> ext_f;
};

}  // namespace grx_sot::robot
