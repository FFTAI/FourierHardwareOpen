/**
 * @file piler.h
 * @brief real-time safe matrix/vector piling .
 *
 * @author wq
 * @date September 25, 2024
 * @version v1.0.2
 * @bug No known bugs
 *
 * @copyright Copyright (c) 2024, shanghai fourier intelligence

 */

#pragma once

#include <Eigen/Dense>

namespace grx_sot::tools {
/**
 * @brief The MatrixPiler class implements real-time safe matrix/vector piling
 */
class MatrixPiler {
 public:
    /**
     * @brief MatrixPiler constructor, the matrix starts with 0 rows
     * @param cols number of columns
     */
    explicit MatrixPiler(const int cols = 0);

    /**
     * @brief reset the number of rows of the matrix to 0
     */
    void reset();

    /**
     * @brief reset the number of rows of the matrix to 0 and set new number of
     * columns
     * @param cols new nnumber of columns
     */
    void reset(const int cols);

    template <typename Derived>
    /**
     * @brief pile a new matrix
     * @param matrix to pile
     */
    void pile(const Eigen::MatrixBase<Derived> &matrix);

    template <typename Derived>
    /**
     * @brief set reset the matrix and initialize with new matrix
     * @param matrix for initialization
     */
    void set(const Eigen::MatrixBase<Derived> &matrix);

    /**
     * @brief generate_and_get
     * @return the actual matrix
     */
    Eigen::Block<Eigen::MatrixXd> generate_and_get();

    /**
     * @brief cols
     * @return number of current columns
     */
    int cols() const { return mat_.cols(); }

    /**
     * @brief rows
     * @return number of current rows
     */
    int rows() const { return current_row_; }

    /**
     * @brief operator [] to index vector
     * @param i index
     * @return value at i
     */
    double &operator[](const int i) { return mat_(i); }

    /**
     * @brief operator () to index matrix
     * @param i row
     * @param j column
     * @return value at (i,j)
     */
    double &operator()(const int i, const int j) { return mat_(i, j); }

 private:
    int cols_;
    int current_row_;

    Eigen::MatrixXd mat_;
};

inline MatrixPiler::MatrixPiler(const int cols)
    : cols_(cols), current_row_(0) {
    mat_.resize(0, cols_);
}

template <typename Derived>
inline void
MatrixPiler::pile(const Eigen::MatrixBase<Derived> &matrix) {
    if (matrix.cols() != cols_) {
        throw std::runtime_error("matrix.cols() != cols_");
    }

    int rows_needed = current_row_ + matrix.rows();

    if (rows_needed > mat_.rows()) {
        mat_.conservativeResize(rows_needed, cols_);
    }

    mat_.block(current_row_, 0, matrix.rows(), matrix.cols()) = matrix;

    current_row_ += matrix.rows();
}

template <typename Derived>
inline void
MatrixPiler::set(const Eigen::MatrixBase<Derived> &matrix) {
    if (cols_ == matrix.cols()) {
        reset();
        pile(matrix);
    } else {
        cols_ = matrix.cols();
        mat_ = matrix;
        current_row_ = mat_.rows();
    }
}

inline void MatrixPiler::reset() { current_row_ = 0; }

inline void MatrixPiler::reset(const int cols) {
    if (cols_ == cols) {
        reset();
    } else {
        cols_ = cols;
        current_row_ = 0;
        mat_.resize(0, cols_);
    }
}

inline Eigen::Block<Eigen::MatrixXd>
MatrixPiler::generate_and_get() {
    return mat_.block(0, 0, current_row_, cols_);
}
}  // namespace grx_sot::tools
