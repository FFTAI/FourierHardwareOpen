/**
 * @file polynorm.h
 * @brief polynom definition and method .
 *
 * @author wq
 * @date Mar 28, 2025
 * @version v1.0.2
 * @bug No known bugs
 *
 * @copyright Copyright (c) 2025, shanghai fourier intelligence

 */
#pragma once

#include <Eigen/Dense>

namespace grx_sot::tools {
class Polynom {
 public:
    Polynom(Eigen::VectorXd coefficients);

    static int derivative_coefficient(int degree, int derivative);

    /**
     * @brief Computes the value of polynom
     * @param x: abscissa
     * @param derivative differentiation order (0: p, 1: p', 2: p'' etc.)
     * @return value
     */
    double value(double x, int derivative = 0);

    /**
     * @brief coefficients, from highest to lowest
     */
    Eigen::VectorXd coefficients;
};
}  // namespace grx_sot::tools
