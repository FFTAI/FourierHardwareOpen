/**
 * @file logger.h
 * @brief use spdlog logging message in console and file .
 *
 * @author wq
 * @date September 25, 2024
 * @version v1.0.2
 * @bug No known bugs
 *
 * @copyright Copyright (c) 2024, shanghai fourier intelligence

 */

#pragma once

#include <memory>
#include <string>

#include <spdlog/sinks/basic_file_sink.h>
#include <spdlog/sinks/rotating_file_sink.h>
#include <spdlog/sinks/stdout_color_sinks.h>
#include <spdlog/spdlog.h>

namespace grx_sot::tools {
/**
 * @brief A wrapper for spdlog .
 */
class Logger {
 public:
    /**
     * @brief construct logger .
     * @param filename the name of log file .
     * @param file_size the max size of log file , unit MB .
     * @param file_sum the max number of files used to logging .
     */
    Logger(const std::string &filename, uint8_t file_size = 3,
           uint8_t file_sum = 3) {
        // create sinks .
        auto console_sink =
            std::make_shared<spdlog::sinks::stdout_color_sink_mt>();
        console_sink->set_pattern("[%Y-%m-%d %H:%M:%S] [%t] [%^%l%$] %v");
        console_sink->set_level(spdlog::level::err);
        auto rotating_sink =
            std::make_shared<spdlog::sinks::rotating_file_sink_mt>
            ("/tmp/logs/"+filename,
                    file_size*1024*1024, file_sum);
        rotating_sink->set_pattern("[%Y-%m-%d %H:%M:%S] [%t] [%^%l%$] %v");

        if (file_size ==0 || file_sum ==0) {
            throw std::runtime_error(
                    "logging size and sum of files must larger than 0 .");
        } else {
            logger = std::make_shared<spdlog::logger>(
                    "multi_sink_logger",
                    spdlog::sinks_init_list{console_sink, rotating_sink});
        }
        logger->set_level(spdlog::level::trace);
    }
    /**
     * @brief log trace .
     * @param message string for message .
     */
    void trace(const std::string &message) {
        logger->trace(message);
        logger->flush();
    }
    /**
     * @brief log debug .
     * @param message string for message .
     */
    void debug(const std::string &message) {
        logger->debug(message);
        logger->flush();
    }
    /**
     * @brief log info .
     * @param message string for message .
     */
    void info(const std::string &message) {
        logger->info(message);
        logger->flush();
    }
    /**
     * @brief log warning .
     * @param message string for message .
     */
    void warn(const std::string &message) {
        logger->warn(message);
        logger->flush();
    }
    /**
     * @brief log error .
     * @param message string for message .
     */
    void error(const std::string &message) {
        logger->error(message);
        logger->flush();
    }
    /**
     * @brief log critical .
     * @param message string for message .
     */
    void critical(const std::string &message) {
        logger->critical(message);
        logger->flush();
    }

 private:
    std::shared_ptr<spdlog::logger> logger;
};
}  // namespace grx_sot::tools
