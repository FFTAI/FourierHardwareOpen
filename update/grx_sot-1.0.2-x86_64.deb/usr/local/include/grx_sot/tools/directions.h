/**
 * @file directions.h
 * @brief direction2d and direction3d .
 *
 * @author wq
 * @date September 22, 2024
 * @version v1.0.2
 * @bug No known bugs
 *
 * @copyright Copyright (c) 2024, shanghai fourier intelligence

 */

#pragma once
#include <vector>
#include <Eigen/Dense>
namespace grx_sot::tools {
/**
 * @brief Generates a set of directions in 2D
 * @param n the number of directions
 * @return matrix of size n x 2
 */
Eigen::MatrixXd directions_2d(int n);
/**
 * @brief Generates a set of directions in 3D, using Fibonacci lattice
 * @param n the number of directions
 * @param epsilon the epsilon parameter for the Fibonacci lattice
 * @return matrix of size n x 3
 */
Eigen::MatrixXd directions_3d(int n, double epsilon = 0.5);
}  // namespace grx_sot::tools
