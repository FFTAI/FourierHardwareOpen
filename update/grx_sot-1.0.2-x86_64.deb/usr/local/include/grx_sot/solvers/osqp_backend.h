/**
 * @file osqp_backend.h
 * @brief osqp backend .
 *
 * @author wq
 * @date September 28, 2024
 * @version v1.0.2
 * @bug No known bugs
 *
 * @copyright Copyright (c) 2024, shanghai fourier intelligence

 */

#pragma once
#include <memory>

#include <Eigen/Sparse>
#include <osqp.h>

#include "solvers/backend.h"
#include "tools/piler.h"

#define OSQP_DEFAULT_EPS_REGULARISATION 0

using namespace grx_sot::tools;

namespace grx_sot::solvers {
/**
 * @brief The OSQPBackEnd class handle variables, options and execution of a
 * single osqp problem. Is implemented using Eigen.
 * This represent the Back-End.
 */
class OSQPBackEnd : public BackEnd {
 public:
    typedef MatrixPiler VectorPiler;

    /**
     * @brief OSQPBackEnd constructor with creation of a QP problem.
     * @param number_of_variables of the QP problem
     * @param number_of_constraints of the QP problem
     * @param eps_regularisation set the Scaling factor of identity matrix used
     * for Hessian regularisation.s
     */
    OSQPBackEnd(
        const int number_of_variables, const int number_of_constraints,
        const double eps_regularisation = OSQP_DEFAULT_EPS_REGULARISATION);

    /**
     * @brief ~OSQPBackEnd destructor
     */
    ~OSQPBackEnd();

    /**
     * @brief initProblem initialize the QP problem and get the solution, the
     * dual solution, bounds and constraints. The QP problem has the following
     * structure:
     *
     *      min = ||Hx - g||
     *  st.     lA <= Ax <= uA
     *           l <=  x <= u
     * @param H Task Matrix
     * @param g Task references
     * @param A Constraint Matrix
     * @param lA lower constraint Eigen::VectorXd
     * @param uA upper constraint Eigen::VectorXd
     * @param l lower bounds
     * @param u upper bounds
     * @return true if the problem can be solved
     */
    virtual bool initProblem(const Eigen::MatrixXd &H, const Eigen::VectorXd &g,
                             const Eigen::MatrixXd &A,
                             const Eigen::VectorXd &lA,
                             const Eigen::VectorXd &uA,
                             const Eigen::VectorXd &l,
                             const Eigen::VectorXd &u);

    /**
     * @brief solve the QP problem
     * @return true if the QP problem is solved
     */
    virtual bool solve();

    /**
     * @brief getOptions return the options of the QP problem
     * @return options
     */
    OSQPSettings getOptions();

    /**
     * @brief setOptions of the QP problem.
     * @param options
     */
    void setOptions(OSQPSettings settings);

    /**
     * @brief updateTask update internal H and g:
     * H_ = H
     * g_ = g
     * for now is not possible to have different size of H and g wrt internal
     * ones
     * @param H updated task matrix
     * @param g updated reference Eigen::VectorXd
     * @return true if task is correctly updated
     */
    virtual bool updateTask(const Eigen::MatrixXd &H, const Eigen::VectorXd &g);

    /**
     * @brief updateConstraints update internal A, lA and uA
     * A_ = A
     * lA_ = lA
     * uA_ = uA
     * A, lA and uA can change rows size to allow variable constraints
     * @param A update constraint matrix
     * @param lA update lower constraint Eigen::VectorXd
     * @param uA update upper constraint Eigen::VectorXd
     * @return true if constraints are correctly updated
     */
    virtual bool updateConstraints(const Eigen::Ref<const Eigen::MatrixXd> &A,
                                   const Eigen::Ref<const Eigen::VectorXd> &lA,
                                   const Eigen::Ref<const Eigen::VectorXd> &uA);

    /**
     * @brief updateBounds update internal l and u
     * l_ = l
     * u_ = u
     * @param l update lower bounds
     * @param u update upper bounds
     * @return true if bounds are correctly updated
     */
    virtual bool updateBounds(const Eigen::VectorXd &l,
                              const Eigen::VectorXd &u);

    /**
     * @brief getObjective to retrieve the value of the objective function
     * @return the value of the objective function at the optimum
     */
    virtual double getObjective();

    /**
     * @brief setEpsRegularisation OVERWRITES the actual eps regularisation
     * factor
     * @param eps the new regularisation factor
     * @return false if eps < 0
     */
    bool setEpsRegularisation(const double eps);

    /**
     * @brief getEpsRegularisation return internal solver eps
     * @return eps value
     */
    virtual double getEpsRegularisation() { return eps_regularisation_; }

 private:
    typedef Eigen::SparseMatrix<double> SparseMatrix;
    typedef Eigen::SparseMatrix<double, Eigen::RowMajor> SparseMatrixRowMajor;

    /**
     * @brief generate_data_struct creates DENSE Hessian and Constraints
     * matrices using a SPARSE representation. Note that bounds are treated as
     * constraints.
     * @param number_of_variables of the QP
     * @param number_of_constraints of the QP
     * @param number_of_bounds of the QP
     */
    void generate_data_struct(const int number_of_variables,
                                const int number_of_constraints,
                                const int number_of_bounds);

    void upper_triangular_sparse_update();

    /**
     * @brief problem_ is the internal OSQPWorkspace
     */
    OSQPWorkspace *workspace_;
    /**
     * @brief data_ internal OSQPData
     */
    std::shared_ptr<OSQPData> data_;

    /**
     * @brief settings_ internal OSQPSettings
     */
    std::shared_ptr<OSQPSettings> settings_;

    Eigen::VectorXd lb_piled_, ub_piled_;

    SparseMatrix Asparse_, Asparse_upper_;
    SparseMatrixRowMajor Asparse_rowmaj_;
    SparseMatrix Psparse_;
    Eigen::MatrixXd Adense_;
    Eigen::VectorXd P_values_;

    std::shared_ptr<csc> Acsc_;
    std::shared_ptr<csc> Pcsc_;

    double eps_regularisation_;
    void setCSCMatrix(csc *a, SparseMatrix &A);
};

}  // namespace grx_sot::solvers
