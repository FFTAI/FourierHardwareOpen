/**
 * @file eiquadprog_backend.h
 * @brief eiquadprog backend .
 *
 * @author wq
 * @date September 25, 2024
 * @version v1.0.2
 * @bug No known bugs
 *
 * @copyright Copyright (c) 2024, shanghai fourier intelligence

 */

#pragma once

#include <memory>

#include "eiquadprog/eiquadprog.hpp"
#include "solvers/backend.h"
#include "tools/piler.h"

#define EIQUADPROG_DEFAULT_EPS_REGULARISATION 0

using namespace grx_sot::tools;

namespace grx_sot::solvers {

/**
 * @brief The eiQuadProgBackEnd class implements a back-end based on eiQuadProg
 * by B. Stepehn https://www.cs.cmu.edu/~bstephe1/eiquadprog.hpp
 */
class eiQuadProgBackEnd : public BackEnd {
 public:
    typedef MatrixPiler VectorPiler;

    eiQuadProgBackEnd(const int number_of_variables,
                      const int number_of_constraints,
                      const double eps_regularisation =
                          EIQUADPROG_DEFAULT_EPS_REGULARISATION);

    ~eiQuadProgBackEnd();

    virtual bool initProblem(const Eigen::MatrixXd &H, const Eigen::VectorXd &g,
                             const Eigen::MatrixXd &A,
                             const Eigen::VectorXd &lA,
                             const Eigen::VectorXd &uA,
                             const Eigen::VectorXd &l,
                             const Eigen::VectorXd &u);

    virtual bool solve();

    virtual double getObjective();

    /**
     * @brief setEpsRegularisation OVERWRITES the actual eps regularisation
     * factor
     * @param eps the new regularisation factor
     * @return false if eps < 0
     */
    bool setEpsRegularisation(const double eps);

    /**
     * @brief getEpsRegularisation return internal solver eps
     * @return eps value
     */
    virtual double getEpsRegularisation() { return eps_regularisation_; }

 private:
    double eps_regularisation_;
    Eigen::MatrixXd I_;

    MatrixPiler CIPiler_;
    VectorPiler ci0Piler_;

    void generate_data_struct();

    double f_value_;
};

}  // namespace grx_sot::solvers
