/**
 * @file proxqp_backend.h
 * @brief proxqp backend .
 *
 * @author wq
 * @date September 28, 2024
 * @version v1.0.2
 * @bug No known bugs
 *
 * @copyright Copyright (c) 2024, shanghai fourier intelligence

 */

#pragma once
#include <memory>
#include <vector>

#include <proxsuite/proxqp/dense/dense.hpp>
#include "solvers/backend.h"
#include "tools/piler.h"

#define PROXQP_DEFAULTeps_regularisation_ 0

using namespace grx_sot::tools;
using namespace proxsuite;
using namespace proxsuite::proxqp;

namespace grx_sot::solvers {

class proxQPBackEnd : public BackEnd {
 public:
    proxQPBackEnd(
        const int number_of_variables, const int number_of_constraints,
        const double eps_regularisation = PROXQP_DEFAULTeps_regularisation_);

    ~proxQPBackEnd();
    virtual bool initProblem(const Eigen::MatrixXd &H, const Eigen::VectorXd &g,
                             const Eigen::MatrixXd &A,
                             const Eigen::VectorXd &lA,
                             const Eigen::VectorXd &uA,
                             const Eigen::VectorXd &l,
                             const Eigen::VectorXd &u);
    virtual bool solve();

    proxsuite::proxqp::Settings<double> getOptions();

    void setOptions(const proxsuite::proxqp::Settings<double> &options);

    virtual bool updateTask(const Eigen::MatrixXd &H, const Eigen::VectorXd &g);

    virtual bool updateConstraints(const Eigen::Ref<const Eigen::MatrixXd> &A,
                                   const Eigen::Ref<const Eigen::VectorXd> &lA,
                                   const Eigen::Ref<const Eigen::VectorXd> &uA);

    virtual bool updateBounds(const Eigen::VectorXd &l,
                              const Eigen::VectorXd &u);

    virtual double getObjective();

    bool setEpsRegularisation(const double eps) {
        if (eps < 0.)
            return false;
        eps_regularisation_ = eps;
        return true;
    }

    virtual double getEpsRegularisation() { return eps_regularisation_; }

 private:
    void create_data_structure(const Eigen::MatrixXd &A,
                               const Eigen::VectorXd &lA,
                               const Eigen::VectorXd &uA,
                               const Eigen::VectorXd &l,
                               const Eigen::VectorXd &u);

    typedef MatrixPiler VectorPiler;

    std::shared_ptr<dense::QP<double>> QP_;

    MatrixPiler AA_;  // equality constr
    VectorPiler b_;
    std::vector<unsigned int> equality_constraint_indices_;
    std::vector<unsigned int> equality_bounds_indices_;

    MatrixPiler G_;  // inequality constr
    VectorPiler ll_, uu_;
    std::vector<unsigned int> inequality_constraint_indices_;
    std::vector<unsigned int> inequality_bounds_indices_;

    Eigen::MatrixXd I_;

    double eps_regularisation_;
};

}  // namespace grx_sot::solvers
