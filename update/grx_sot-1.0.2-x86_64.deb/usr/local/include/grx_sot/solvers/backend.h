/**
 * @file backend.h
 * @brief a base class for different solver .
 *
 * @author wq
 * @date September 25, 2024
 * @version v1.0.2
 * @bug No known bugs
 *
 * @copyright Copyright (c) 2024, shanghai fourier intelligence

 */

#pragma once

#include <Eigen/Dense>
#include <memory>

namespace grx_sot::solvers {
enum HessianType {
    HST_ZERO,             /**< Hessian is zero matrix (i.e. LP formulation). */
    HST_IDENTITY,         /**< Hessian is identity matrix. */
    HST_POSDEF,           /**< Hessian is (strictly) positive definite. */
    //  Hessian is positive definite on null space of active bounds/constraints.
    HST_POSDEF_NULLSPACE,
    HST_SEMIDEF,          /**< Hessian is positive semi-definite. */
    HST_UNKNOWN           /**< Hessian type is unknown. */
};
class BackEnd {
 public:
    BackEnd(const int number_of_variables, const int number_of_constraints);
    virtual ~BackEnd();

    typedef std::shared_ptr<BackEnd> Ptr;

    /**
     * @brief getSolution return the actual solution of the QP problem
     * @return solution
     */
    const Eigen::VectorXd &getSolution() { return solution_; }

    /**
     * Getters for internal matrices and Eigen::VectorXds
     */
    const Eigen::MatrixXd &getH() { return H_; }
    const Eigen::VectorXd &getg() { return g_; }
    const Eigen::MatrixXd &getA() { return A_; }
    const Eigen::VectorXd &getlA() { return lA_; }
    const Eigen::VectorXd &getuA() { return uA_; }
    const Eigen::VectorXd &getl() { return l_; }
    const Eigen::VectorXd &getu() { return u_; }

    int getNumVariables() const;
    int getNumConstraints() const;

    /**
     * @brief updateProblem update the whole problem see updateTask(),
     * updateConstraints() and updateBounds()
     * @param H updated task matrix
     * @param g updated reference Eigen::VectorXd
     * @param A update constraint matrix
     * @param lA update lower constraint Eigen::VectorXd
     * @param uA update upper constraint Eigen::VectorXd
     * @param l update lower bounds
     * @param u update upper bounds
     * @return if the problem is correctly updated
     */
    bool updateProblem(const Eigen::MatrixXd &H, const Eigen::VectorXd &g,
                       const Eigen::MatrixXd &A, const Eigen::VectorXd &lA,
                       const Eigen::VectorXd &uA, const Eigen::VectorXd &l,
                       const Eigen::VectorXd &u);

    /**
     * @brief updateTask update internal H and g:
     * H_ = H
     * g_ = g
     * for now is not possible to have different size of H and g wrt internal
     * ones
     * @param H updated task matrix
     * @param g updated reference Eigen::VectorXd
     * @return true if task is correctly updated
     */
    virtual bool updateTask(const Eigen::MatrixXd &H, const Eigen::VectorXd &g);

    /**
     * @brief updateConstraints update internal A, lA and uA
     * A_ = A
     * lA_ = lA
     * uA_ = uA
     * A, lA and uA can change rows size to allow variable constraints
     * @param A update constraint matrix
     * @param lA update lower constraint Eigen::VectorXd
     * @param uA update upper constraint Eigen::VectorXd
     * @return true if constraints are correctly updated
     */
    virtual bool updateConstraints(const Eigen::Ref<const Eigen::MatrixXd> &A,
                                   const Eigen::Ref<const Eigen::VectorXd> &lA,
                                   const Eigen::Ref<const Eigen::VectorXd> &uA);

    /**
     * @brief updateBounds update internal l and u
     * l_ = l
     * u_ = u
     * @param l update lower bounds
     * @param u update upper bounds
     * @return true if bounds are correctly updated
     */
    virtual bool updateBounds(const Eigen::VectorXd &l,
                              const Eigen::VectorXd &u);

    /**
     * @brief initProblem initialize the QP problem and get the solution, the
     * dual solution, bounds and constraints. The QP problem has the following
     * structure:
     *
     *      min = 0.5x'Hx + g'x
     *  st.     lA <= Ax <= uA
     *           l <=  x <= u
     * @param H Task Matrix
     * @param g Task references
     * @param A Constraint Matrix
     * @param lA lower constraint Eigen::VectorXd
     * @param uA upper constraint Eigen::VectorXd
     * @param l lower bounds
     * @param u upper bounds
     * @return true if the problem can be solved
     */
    virtual bool initProblem(const Eigen::MatrixXd &H, const Eigen::VectorXd &g,
                             const Eigen::MatrixXd &A,
                             const Eigen::VectorXd &lA,
                             const Eigen::VectorXd &uA,
                             const Eigen::VectorXd &l,
                             const Eigen::VectorXd &u) = 0;
    /**
     * @brief solve the QP problem
     * @return true if the QP problem is solved (implementation should use
     * internally solution)
     */
    virtual bool solve() = 0;

    /**
     * @brief getObjective to retrieve the value of the objective function
     * @return the value of the objective function at the optimum
     */
    virtual double getObjective() = 0;

    /**
     * @brief setEpsRegularisation is used to set internal solver eps
     * @param eps regularisation
     * @return false by default
     */
    virtual bool setEpsRegularisation(const double eps) { return false; }

    /**
     * @brief getEpsRegularisation return internal solver eps
     * @return eps value
     */
    virtual double getEpsRegularisation() { return 0; }

 protected:
    /**
     * Define a cost function: ||Hx - g||
     */
    Eigen::MatrixXd H_;
    Eigen::VectorXd g_;

    /**
     * Define a set of constraints weighted with A: lA <= Ax <= uA
     */
    Eigen::MatrixXd A_;
    Eigen::VectorXd lA_;
    Eigen::VectorXd uA_;

    /**
     * Define a set of bounds on solution: l <= x <= u
     */
    Eigen::VectorXd l_;
    Eigen::VectorXd u_;

    /**
     * Solution of the QP problem
     */
    Eigen::VectorXd solution_;

    /**
     * @brief _number_of_variables which remain constant during BE existence
     */
    int number_of_variables_;
};

}  // namespace grx_sot::solvers
