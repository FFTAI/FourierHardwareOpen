/**
 * @file polygon_constraint.h
 * @brief build 2D polygon belonging constraints .
 * @author wq
 * @date September 22, 2024
 * @version v1.0.2
 * @bug No known bugs
 *
 * @copyright Copyright (c) 2024, shanghai fourier intelligence

 */

#pragma once

#include <vector>
#include "problem/problem.h"

namespace grx_sot::problem {
/**
 * @brief Provides convenient helpers to build 2D polygon belonging constraints
 */
class PolygonConstraint {
 public:
  /**
   * @brief Given a polygon, produces inequalities so that the given point lies inside the polygon.
   * WARNING: Polygon must be clockwise (meaning that the exterior of the shape is on the trigonometric normal of
   * the vertices)
   *
   * ```text
   *          B
   *          X
   *        . .
   *      .   . ---> normal
   *    .     .
   *  X.......X
   *  A       C
   * ```
   */
  static ProblemConstraint in_polygon_xy(
    const Expression& expression_xy,
    std::vector<Eigen::Vector2d> polygon,
    double margin = 0.);

  /**
   * See \ref in_polygon_xy
   */
  static ProblemConstraint in_polygon(
    const Expression& expression_x, const Expression& expression_y,
    std::vector<Eigen::Vector2d> polygon, double margin = 0.);
};
}  // namespace grx_sot::problem
