/**
 * @file qp_error.h
 * @brief qp error.
 * @author wq
 * @date September 22, 2024
 * @version v1.0.2
 * @bug No known bugs
 *
 * @copyright Copyright (c) 2024, shanghai fourier intelligence

 */

#pragma once

#include <stdexcept>
#include <string>

namespace grx_sot::problem {
/**
 * @brief Exception raised by \ref Problem in case of failure
 */
class QPError : public std::runtime_error {
 public:
  explicit QPError(std::string message = "");
};
}  // namespace grx_sot::problem
