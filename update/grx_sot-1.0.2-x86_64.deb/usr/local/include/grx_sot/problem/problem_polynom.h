/**
 * @file problem_polynom.h
 * @brief Represents a polynom for which decision variables are problem coefficients .
 * @author wq
 * @date Mar 28, 2025
 * @version v1.0.2
 * @bug No known bugs
 *
 * @copyright Copyright (c) 2025, shanghai fourier intelligence

 */

#pragma once

#include <memory>
#include <map>
#include "tools/polynom.h"
#include "problem/variable.h"
#include "problem/expression.h"

namespace grx_sot::problem {
/**
 * @brief Represents a polynom for which decision variables are problem coefficients
 */
class ProblemPolynom {
 public:
    ProblemPolynom(Variable& variable);

    /**
     * @brief Builds a problem expression for the value of the polynom
     * @param x: abscissa
     * @param derivative differentiation order (0: p, 1: p', 2: p'' etc.)
     * @return problem expression
     */
    Expression expr(double x, int derivative = 0);

    /**
     * @brief Obtain resulting polynom (after problem is solved)
     * @return
     */
    grx_sot::tools::Polynom get_polynom();

 protected:
    // Decision variable
    Variable* variable;
};
}  // namespace grx_sot::problem
