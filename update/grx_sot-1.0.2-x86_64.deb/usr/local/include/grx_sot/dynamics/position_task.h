/**
 * @file position_task.h
 * @brief dynamic position task .
 *
 * @author wq
 * @date September 23, 2024
 * @version v1.0.2
 * @bug No known bugs
 *
 * @copyright Copyright (c) 2024, shanghai fourier intelligence

 */

#pragma once

#include <string>

#include "dynamics/task.h"
#include "robot/robot_wrapper.h"
#include "tools/axises_mask.h"

namespace grx_sot::dynamics {
class PositionTask : public Task {
 public:
    /**
     * @brief see \ref grx_sot::dynamics::DynamicsSolver::add_position_task
     */
    PositionTask(robot::RobotWrapper::FrameIndex frame_index,
                 Eigen::Vector3d target_world);

    /**
     * @brief Frame
     */
    robot::RobotWrapper::FrameIndex frame_index;

    /**
     * @brief Target position in the world
     */
    Eigen::Vector3d target_world;

    /**
     * @brief Target velocity in the world
     */
    Eigen::Vector3d dtarget_world = Eigen::Vector3d::Zero();

    /**
     * @brief Target acceleration in the world
     */
    Eigen::Vector3d ddtarget_world = Eigen::Vector3d::Zero();

    void update() override;
    std::string type_name() override;
    std::string error_unit() override;

    /**
     * @brief Mask
     */
    tools::AxisesMask mask;
};
}  // namespace grx_sot::dynamics
