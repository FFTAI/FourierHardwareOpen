/**
 * @file constraint.h
 * @brief base class of constraint .
 *
 * @author wq
 * @date September 23, 2024
 * @version v1.0.2
 * @bug No known bugs
 *
 * @copyright Copyright (c) 2024, shanghai fourier intelligence

 */

#pragma once

#include "problem/problem.h"
#include "tools/prioritized.h"

namespace grx_sot::dynamics {
class DynamicsSolver;
class Constraint : public tools::Prioritized {
 public:
    /**
     * @brief Reference to the dynamics solver
     */
    DynamicsSolver *solver = nullptr;

    /**
     * @brief true if this object memory is in the solver (it will be deleted by
     * the solver)
     */
    bool solver_memory = false;

    /**
     * @brief Allows the specific constraint implementation to be added to the
     * problem
     * @param problem problem
     * @param tau expression for tau
     */
    virtual void add_constraint(problem::Problem &problem,
                                problem::Expression &tau) = 0;
};
}  // namespace grx_sot::dynamics
