/**
 * @file com_task.h
 * @brief dynamic com task .
 *
 * @author wq
 * @date September 23, 2024
 * @version v1.0.2
 * @bug No known bugs
 *
 * @copyright Copyright (c) 2024, shanghai fourier intelligence

 */

#pragma once

#include <string>
#include "dynamics/task.h"
#include "robot/robot_wrapper.h"
#include "tools/axises_mask.h"

namespace grx_sot::dynamics {
class CoMTask : public Task {
 public:
  /**
   * @brief see \ref grx_sot::dynamics::DynamicsSolver::add_com_task
   */
  explicit CoMTask(Eigen::Vector3d target_world);

  /**
   * @brief Target to reach in world frame
   */
  Eigen::Vector3d target_world;

  /**
   * @brief Target velocity to reach in robot frame
   */
  Eigen::Vector3d dtarget_world = Eigen::Vector3d::Zero();

  /**
   * @brief Target acceleration in the world
   */
  Eigen::Vector3d ddtarget_world = Eigen::Vector3d::Zero();

  void update() override;
  std::string type_name() override;
  std::string error_unit() override;

  /**
   * @brief Axises mask
   */
  tools::AxisesMask mask;
};
}  // namespace grx_sot::dynamics
