/**
 * @file relative_frame_task.h
 * @brief dynamic relative frame task .
 *
 * @author wq
 * @date September 23, 2024
 * @version v1.0.2
 * @bug No known bugs
 *
 * @copyright Copyright (c) 2024, shanghai fourier intelligence

 */

#pragma once

#include <string>

#include "dynamics/orientation_task.h"
#include "dynamics/relative_orientation_task.h"
#include "dynamics/relative_position_task.h"

namespace grx_sot::dynamics {
struct RelativeFrameTask {
    /**
     * @brief see \ref
     * grx_sot::dynamics::DynamicsSolver::add_relative_frame_task
     */
    RelativeFrameTask();

    /**
     * @brief see \ref
     * grx_sot::dynamics::DynamicsSolver::add_relative_frame_task
     */
    RelativeFrameTask(RelativePositionTask *position,
                      RelativeOrientationTask *orientation);

    /**
     * @brief Configures the relative frame task
     * @param name task name
     * @param priority task priority
     * @param position_weight weight for the position task
     * @param orientation_weight weight for the orientation task
     */
    void configure(std::string name, std::string priority = "soft",
                   double position_weight = 1.0,
                   double orientation_weight = 1.0);

    /**
     * @brief Position task
     */
    RelativePositionTask *position;

    /**
     * @brief Orientation task
     */
    RelativeOrientationTask *orientation;

    /**
     * @brief Retrieve the relative frame from tasks
     * @return transformation
     */
    Eigen::Affine3d get_T_a_b() const;

    /**
     * @brief Set the relative frame target for tasks
     * @param T_a_b transformation
     */
    void set_T_a_b(Eigen::Affine3d T_a_b);
};
}  // namespace grx_sot::dynamics
