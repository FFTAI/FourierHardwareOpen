/**
 * @file joints_task.h
 * @brief joints task .
 *
 * @author wq
 * @date September 23, 2024
 * @version v1.0.2
 * @bug No known bugs
 *
 * @copyright Copyright (c) 2024, shanghai fourier intelligence

 */

#pragma once

#include <map>
#include <string>

#include "dynamics/task.h"
#include "robot/robot_wrapper.h"
#include "tools/axises_mask.h"

namespace grx_sot::dynamics {
class JointsTask : public Task {
 public:
    /**
     * @brief see \ref grx_sot::dynamics::DynamicsSolver::add_gear_task
     */
    JointsTask();

    /**
     * @brief Maps joint to position targets
     */
    std::map<std::string, double> joints;

    /**
     * @brief Maps joints to velocity targets
     */
    std::map<std::string, double> djoints;

    /**
     * @brief Maps joints to acceleration targets
     */
    std::map<std::string, double> ddjoints;

    /**
     * @brief Sets the target for a given joint
     * @param joint joint name
     * @param target target position
     * @param velocity target velocity
     * @param acceleration target acceleration
     */
    void set_joint(std::string joint, double target, double velocity = 0.,
                   double acceleration = 0.);

    /**
     * @brief Returns the current target position of a joint
     * @param joint joint name
     * @return current target position
     */
    double get_joint(std::string joint);

    void update() override;
    std::string type_name() override;
    std::string error_unit() override;
};
}  // namespace grx_sot::dynamics
