/**
 * @file relative_position_task.h
 * @brief dynamic relative position task .
 *
 * @author wq
 * @date September 23, 2024
 * @version v1.0.2
 * @bug No known bugs
 *
 * @copyright Copyright (c) 2024, shanghai fourier intelligence

 */

#pragma once

#include <string>
#include "dynamics/task.h"
#include "robot/robot_wrapper.h"
#include "tools/axises_mask.h"

namespace grx_sot::dynamics {
class RelativePositionTask : public Task {
 public:
    RelativePositionTask(robot::RobotWrapper::FrameIndex frame_a_index,
                         robot::RobotWrapper::FrameIndex frame_b_index,
                         Eigen::Vector3d target_world);

    /**
     * @brief Frame A
     */
    robot::RobotWrapper::FrameIndex frame_a_index;

    /**
     * @brief Frame B
     */
    robot::RobotWrapper::FrameIndex frame_b_index;

    /**
     * @brief Target relative position
     */
    Eigen::Vector3d target;

    /**
     * @brief Target relative velocity
     */
    Eigen::Vector3d dtarget = Eigen::Vector3d::Zero();

    /**
     * @brief Target relative acceleration
     */
    Eigen::Vector3d ddtarget = Eigen::Vector3d::Zero();

    void update() override;
    std::string type_name() override;
    std::string error_unit() override;

    /**
     * @brief Mask
     */
    tools::AxisesMask mask;
};
}  // namespace grx_sot::dynamics
