/**
 * @file gear_task.h
 * @brief dynamic gear task .
 *
 * @author wq
 * @date September 23, 2024
 * @version v1.0.2
 * @bug No known bugs
 *
 * @copyright Copyright (c) 2024, shanghai fourier intelligence

 */

#pragma once

#include <map>
#include <string>

#include "dynamics/task.h"
#include "robot/robot_wrapper.h"
#include "tools/axises_mask.h"

namespace grx_sot::dynamics {
class GearTask : public Task {
 public:
    /**
     * @brief see \ref grx_sot::dynamics::DynamicsSolver::add_gear_task
     */
    GearTask();

    /**
     * @brief Gear settings
     */
    std::map<int, std::map<int, double>> gears;

    /**
     * @brief Sets a gear constraint
     * @param target target joint
     * @param source source joint
     * @param ratio ratio
     */
    void set_gear(std::string target, std::string source, double ratio);

    /**
     * @brief Adds a gear constraint, you can add multiple source for the same
     * target, they will be summed
     * @param target target joint
     * @param source source joint
     * @param ratio ratio
     */
    void add_gear(std::string target, std::string source, double ratio);

    void update() override;
    std::string type_name() override;
    std::string error_unit() override;
};
}  // namespace grx_sot::dynamics
