/**
 * @file torque_task.h
 * @brief torque task .
 *
 * @author wq
 * @date September 23, 2024
 * @version v1.0.2
 * @bug No known bugs
 *
 * @copyright Copyright (c) 2024, shanghai fourier intelligence

 */

#pragma once

#include <map>
#include <string>

#include "dynamics/task.h"
#include "robot/robot_wrapper.h"
#include "tools/axises_mask.h"

namespace grx_sot::dynamics {
class TorqueTask : public Task {
 public:
    struct TargetTau {
        /**
         * @brief Torque to apply
         */
        double torque = 0.0;

        /**
         * @brief Proportional gain
         */
        double kp = 0.0;

        /**
         * @brief Derivative gain (damping)
         */
        double kd = 0.0;
    };

    /**
     * @brief see \ref grx_sot::dynamics::DynamicsSolver::add_tau_task
     */
    TorqueTask();

    /**
     * @brief Target torques
     */
    std::map<std::string, TargetTau> torques;

    /**
     * @brief Sets the target for a given joint
     * @param joint joint name
     * @param torque target torque
     * @param kp proportional gain (optional)
     * @param kd derivative gain (optional)
     */
    void set_torque(std::string joint, double torque, double kp = 0.0,
                    double kd = 0.0);

    /**
     * @brief Removes a joint from this task
     * @param joint joint namle
     */
    void reset_torque(std::string joint);

    void update() override;
    std::string type_name() override;
    std::string error_unit() override;
};
}  // namespace grx_sot::dynamics
