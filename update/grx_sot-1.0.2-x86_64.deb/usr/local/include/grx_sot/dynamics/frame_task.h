/**
 * @file frame_task.h
 * @brief dynamic frame task .
 *
 * @author wq
 * @date September 23, 2024
 * @version v1.0.2
 * @bug No known bugs
 *
 * @copyright Copyright (c) 2024, shanghai fourier intelligence

 */

#pragma once

#include <string>

#include "dynamics/orientation_task.h"
#include "dynamics/position_task.h"

namespace grx_sot::dynamics {
struct FrameTask {
    /**
     * @brief see \ref grx_sot::dynamics::DynamicsSolver::add_frame_task
     */
    FrameTask();

    /**
     * @brief see \ref grx_sot::dynamics::DynamicsSolver::add_frame_task
     */
    FrameTask(PositionTask *position, OrientationTask *orientation);

    /**
     * @brief Configures the frame task
     * @param name task name
     * @param priority task priority
     * @param position_weight weight for the position task
     * @param orientation_weight weight for the orientation task
     */
    void configure(std::string name, std::string priority = "soft",
                   double position_weight = 1.0,
                   double orientation_weight = 1.0);

    PositionTask *position;
    OrientationTask *orientation;

    Eigen::Affine3d get_T_world_frame() const;
    void set_T_world_frame(Eigen::Affine3d T_world_frame);
};
}  // namespace grx_sot::dynamics
