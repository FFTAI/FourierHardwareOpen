/**
 * @file avoid_self_collisions_constraint.h
 * @brief avoid self collisions .
 *
 * @author wq
 * @date September 23, 2024
 * @version v1.0.2
 * @bug No known bugs
 *
 * @copyright Copyright (c) 2024, shanghai fourier intelligence

 */

#pragma once

#include "dynamics/constraint.h"
#include "problem/problem.h"

namespace grx_sot::dynamics {
class DynamicsSolver;
class AvoidSelfCollisionsConstraint : public Constraint {
 public:
    /**
     * @brief Margin for self collisions [m]
     */
    double self_collisions_margin = 0.005;

    /**
     * @brief Distance that triggers the constraint [m]
     */
    double self_collisions_trigger = 0.01;

    void add_constraint(problem::Problem &problem,
                        problem::Expression &tau) override;
};
}  // namespace grx_sot::dynamics
